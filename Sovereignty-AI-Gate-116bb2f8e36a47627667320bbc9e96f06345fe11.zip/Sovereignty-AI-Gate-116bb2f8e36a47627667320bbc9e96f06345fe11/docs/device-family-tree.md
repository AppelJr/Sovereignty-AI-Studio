# Device-Local Family Tree Storage

**Status:** Authoritative device-local layout  
**Source of truth:** Screenshots + this document  
**Network:** Disabled by default  
**External memory:** Disabled by default

## Layout

```
/Admin/On Device Memory Storage/
├── GitHub Copilot Local Storage/
├── Anthropic Claude Fable Local Storage/
├── OpenAI ChatGPT Codex Local Storage/
├── X.AI Grok Local Storage/
├── DuckAI Local Storage/
├── DevAssist420 Local Hybrid Collaboration/
├── Sovereignty AI/
├── Router/Council/
│   ├── Claude
│   ├── Ara-Grok
│   ├── ChatGPT-Codex
│   ├── DevAssist420
│   ├── DuckAI
│   ├── GitHub Copilot
│   └── Sovereignty AI
├── audit/
└── hybrid/
```

## Important Boundary

Folders named after providers (GitHub Copilot, Claude, OpenAI, Grok, DuckAI) are **local storage identities only**.  
They do **not** prove that those providers are running locally.  
No remote provider is contacted until an actual local model/runtime is installed and verified.

## Provider Registry

Created at `$ROOT/provider-registry.json` by the bootstrap script.

Each provider entry contains:

- `id`
- `name`
- `role`
- `storage` (relative folder)
- `network: false`

## Wake Word / TTS

```json
{
  "wake_word": "hey ara",
  "recognition": "local_engine_required",
  "remote_recognition": false,
  "tts": "local_engine_required"
}
```

Voice recognition and TTS remain local-engine only. Remote recognition is forbidden.

## Dashboard Panel Requirements

The family-tree panel must display for every provider:

```
IDENTITY
ROLE
LOCAL STORAGE
MEMORY: DEVICE ONLY
NETWORK: DISABLED
AUTHORIZATION: NOT EVALUATED / AUTHORIZED / ACCESSDENIED
SCAR HISTORY
```

## Bootstrap

```bash
chmod +x scripts/create-device-family-tree.sh
./scripts/create-device-family-tree.sh
```

Optional override:

```bash
SOVEREIGN_STATE_ROOT=/path/to/custom/root ./scripts/create-device-family-tree.sh
```

## Audit Rule

Every provider action must record:

- who
- what
- when
- where
- why
- how
- authorization
- memory_loaded
- network_accessed
- files_changed
- result
