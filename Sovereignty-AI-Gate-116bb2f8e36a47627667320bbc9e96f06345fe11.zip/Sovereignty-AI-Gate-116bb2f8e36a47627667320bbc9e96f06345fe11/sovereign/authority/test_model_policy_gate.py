from sovereign.authority.model_policy_gate import authorize_model

POLICY = {
    "ownerAuthority": True,
    "blockedModels": ["Google Gemini", "llama"],
    "lastValidNonBlockedModel": "GPT 5.4 mini",
    "requireNotification": True,
    "failClosed": True,
}


def test_owner_low_risk_authorized():
    result = authorize_model("gpt-5.4-mini", POLICY, "ui_picker", actor_type="owner")
    assert result["decision"] == "OWNER_AUTHORIZED"
    assert result["checkpoint_id"] is None


def test_owner_high_risk_requires_confirmation():
    result = authorize_model("gpt-5.4-mini", POLICY, "voice_command", actor_type="owner", risk_level="high")
    assert result["decision"] == "CONFIRMATION_REQUIRED"
    assert result["checkpoint_id"]
    assert result["scar_event"]["decision"] == "CONFIRMATION_REQUIRED"


def test_owner_explicit_override_is_one_action():
    result = authorize_model("google.gemini", POLICY, "router", actor_type="owner", confirmation=True, override=True)
    assert result["decision"] == "OWNER_OVERRIDE"
    assert result["override_scope"] == "single_action"
    assert result["override_lifetime"] == "transaction_end"
    assert result["policy_modified"] is False


def test_model_cannot_override():
    result = authorize_model("google.gemini", POLICY, "council", actor_type="model", confirmation=True, override=True)
    assert result["decision"] == "ACCESS_DENIED"
    assert result["reason"] == "user_blocked"


def test_delegated_capability_scope():
    allowed = authorize_model("gpt-5.4-mini", POLICY, "router", actor_type="delegated", capability_scope="model_selection")
    denied = authorize_model("gpt-5.4-mini", POLICY, "router", actor_type="delegated", capability_scope="write_repository")
    assert allowed["decision"] == "DELEGATED_AUTHORIZED"
    assert denied["decision"] == "ACCESS_DENIED"
    assert denied["reason"] == "capability_scope_violation"


def test_override_cannot_escalate_permissions():
    result = authorize_model("gpt-5.4-mini", POLICY, "router", actor_type="owner", risk_level="critical", confirmation=True, override=True)
    assert result["decision"] == "OWNER_OVERRIDE"
    assert result["policy_modified"] is False
    assert result["override_scope"] == "single_action"


def test_invalid_policy_fails_closed():
    result = authorize_model("gpt-5.4-mini", {}, "router")
    assert result["decision"] == "ACCESS_DENIED"
    assert result["reason"] == "invalid_policy"


def test_blocked_fallback_is_never_selected():
    result = authorize_model("gemini", {**POLICY, "lastValidNonBlockedModel": "llama"}, "auto_selection")
    assert result["decision"] == "ACCESS_DENIED"
    assert result["fallback_model"] is None


def test_scar_written_for_every_decision():
    for decision_kwargs in ({}, {"risk_level": "high"}, {"actor_type": "model"}):
        result = authorize_model("gpt-5.4-mini", POLICY, "router", **decision_kwargs)
        assert result["scar_event"]["scar_id"].startswith("scar-")
