from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Optional
from uuid import uuid4

ENTRYPOINTS = frozenset({
    "ui_picker", "voice_command", "router", "council", "auto_selection", "session_restore",
})
DECISIONS = frozenset({
    "OWNER_AUTHORIZED", "DELEGATED_AUTHORIZED", "CONFIRMATION_REQUIRED", "OWNER_OVERRIDE", "ACCESS_DENIED",
})

@dataclass(frozen=True)
class AuthorizationResult:
    decision: str
    model: str
    reason: str
    ui_state: str
    source: str
    actor_type: str
    fallback_model: Optional[str]
    checkpoint_id: Optional[str]
    override_scope: Optional[str]
    override_lifetime: Optional[str]
    policy_modified: bool
    scar_event: Dict[str, Any]


def _normalize_model_id(model_id: str) -> str:
    if not isinstance(model_id, str):
        return ""
    return ".".join(model_id.strip().lower().replace("_", ".").split())


def _policy_valid(policy: object) -> bool:
    return (
        isinstance(policy, dict)
        and policy.get("ownerAuthority") is True
        and isinstance(policy.get("blockedModels"), list)
        and policy.get("failClosed") is True
    )


def _blocked_models(policy: Dict[str, Any]) -> frozenset[str]:
    return frozenset(_normalize_model_id(value) for value in policy["blockedModels"])


def _fallback(policy: Dict[str, Any], blocked: frozenset[str]) -> Optional[str]:
    candidate = _normalize_model_id(policy.get("lastValidNonBlockedModel", ""))
    return candidate if candidate and candidate not in blocked else None


def evaluate_model_access(
    model_id: str,
    policy: Dict[str, Any],
    source: str,
    *,
    actor_type: str = "owner",
    risk_level: str = "normal",
    confirmation: bool = False,
    override: bool = False,
    capability_scope: Optional[str] = None,
) -> Dict[str, Any]:
    model = _normalize_model_id(model_id)
    origin = source.strip() if isinstance(source, str) else ""
    origin = origin if origin in ENTRYPOINTS else "unknown"
    actor = actor_type if actor_type in {"owner", "delegated", "model", "tool", "plugin"} else "unknown"
    blocked = _blocked_models(policy) if _policy_valid(policy) else frozenset()
    checkpoint_id = None
    override_scope = None
    override_lifetime = None
    reason = "allowed_by_owner_policy"
    decision = "OWNER_AUTHORIZED" if actor == "owner" else "DELEGATED_AUTHORIZED"
    ui_state = "Authorization"
    fallback = None

    if not _policy_valid(policy):
        decision, reason, ui_state = "ACCESS_DENIED", "invalid_policy", "AccessDENIED"
    elif model in blocked:
        fallback = _fallback(policy, blocked)
        if actor == "owner" and override and confirmation:
            decision, reason, ui_state = "OWNER_OVERRIDE", "owner_confirmed_blocked_model", "Authorization"
            checkpoint_id = f"checkpoint-{uuid4()}"
            override_scope, override_lifetime = "single_action", "transaction_end"
        else:
            decision, reason, ui_state = "ACCESS_DENIED", "user_blocked", "AccessDENIED"
    elif actor != "owner" and capability_scope not in {None, "model_selection"}:
        decision, reason, ui_state = "ACCESS_DENIED", "capability_scope_violation", "AccessDENIED"
    elif actor == "model":
        decision, reason, ui_state = "ACCESS_DENIED", "model_cannot_authorize", "AccessDENIED"
    elif risk_level in {"high", "critical"} and not confirmation:
        decision, reason, ui_state = "CONFIRMATION_REQUIRED", "owner_confirmation_required", "AccessDENIED"
        checkpoint_id = f"checkpoint-{uuid4()}"
    elif risk_level in {"high", "critical"} and confirmation:
        checkpoint_id = f"checkpoint-{uuid4()}"
        if override:
            decision, reason, ui_state = "OWNER_OVERRIDE", "owner_confirmed_override", "Authorization"
            override_scope, override_lifetime = "single_action", "transaction_end"

    scar = {
        "event_type": "MODEL_ACCESS_DECISION",
        "model": model,
        "source": origin,
        "actor_type": actor,
        "decision": decision,
        "reason": reason,
        "confirmation": confirmation,
        "checkpoint_id": checkpoint_id,
        "override_scope": override_scope,
        "override_expires": override_lifetime,
        "policy_modified": False,
        "requires_notification": decision in {"ACCESS_DENIED", "CONFIRMATION_REQUIRED"},
        "scar_id": f"scar-{uuid4()}",
    }
    result = AuthorizationResult(
        decision, model, reason, ui_state, origin, actor, fallback,
        checkpoint_id, override_scope, override_lifetime, False, scar,
    )
    return result.__dict__


def authorize_model(model_id: str, policy: Dict[str, Any], source: str = "unknown", **kwargs: Any) -> Dict[str, Any]:
    return evaluate_model_access(model_id, policy, source, **kwargs)
