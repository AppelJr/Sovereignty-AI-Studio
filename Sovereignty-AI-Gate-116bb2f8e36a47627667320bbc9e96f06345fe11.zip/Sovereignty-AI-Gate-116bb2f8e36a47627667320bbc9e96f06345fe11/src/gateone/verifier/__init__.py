"""Gate.one verification primitives."""
